# Unity files for the survey

In order to be used, the folder  ML Survey/Assets/Resources/Images must be filled with the images to use in the battles. It is also necessary to change the inspector value 'maxID' of the NewGM object to the maximum ID of the images + 1 (in our case 457 + 1 = 458)
