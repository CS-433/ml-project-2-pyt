﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NewGM : MonoBehaviour
{
    //JUST DEBUG
    public bool export = true;

    [Header("Dataset")]
    public int maxId = 11; //Maximum image Id
    public int nbRounds = 5; //Total number of rounds
    [HideInInspector] public int nbSprites; //Total number of sprites loaded

    [Header("Images")]
    public MyImage image1;
    public MyImage image2;

    [Header("EndCanvas")]
    public GameObject endCanvas;

    //Variables used later
    private int currentIndex = 0;
    string path;
    Sprite newSprite;

    //Export variables
    string age = PlayerStats.age;
    string gender = PlayerStats.gender;
    string origin = PlayerStats.origin;
    string residence = PlayerStats.residence;
    string percentage = PlayerStats.percentage;

    private AudioManager audioManager;
    private XpManager xpManager;
    [HideInInspector] public Sprite[] sprites1;
    [HideInInspector] public Sprite[] sprites2;
    [HideInInspector] public int[] ids1;
    [HideInInspector] public int[] ids2;

    private void Start()
    {
        audioManager = FindObjectOfType<AudioManager>();
        xpManager = GetComponent<XpManager>();

        //Initialize dataset variables
        nbSprites = nbRounds * 2;
        sprites1 = new Sprite[nbRounds];
        sprites2 = new Sprite[nbRounds];
        ids1 = new int[nbRounds];
        ids2 = new int[nbRounds];

        //Load the images for this game, then start the game
        StartCoroutine(GetSprites());
    }

    IEnumerator GetSprites()
    {
        int[] indices = new int[nbSprites];
        int rdmId = 0;
        bool alreadyIn = false;
        for (int i = 0; i < nbSprites; i++)
        {
            do //Don't load same image twice
            {
                alreadyIn = false;
                rdmId = Random.Range(0, maxId);
                for (int j = 0; j < i; j++)
                {
                    if (indices[j] == rdmId)
                    {
                        alreadyIn = true;
                        break;
                    }
                }
            } while (alreadyIn);
            indices[i] = rdmId;

            path = "Images/" + rdmId.ToString();
            newSprite = Resources.Load<Sprite>(path);

            if(i < nbRounds) //Put the first half in sprites1 and the second in sprites2
            {
                sprites1[i] = newSprite;
                ids1[i] = rdmId;
            } else
            {
                sprites2[i - nbRounds] = newSprite;
                ids2[i - nbRounds] = rdmId;
            }
        }

        yield return null;

        UpdateNewImages();
    }
    public void UpdateNewImages()
    {
        if(currentIndex < nbRounds)
        {
            int id1 = ids1[currentIndex];
            int id2 = ids2[currentIndex];

            //Update images
            image1.UpdateImage(id1, sprites1[currentIndex]);
            image2.UpdateImage(id2, sprites2[currentIndex]);

            currentIndex += 1;

        } else
        {
            endCanvas.SetActive(true);
        }

    }

    public void exportResult(int winImage)
    {
        //Satisfaction
        audioManager.Play("ImageClick", true);
        xpManager.endRound(Mathf.Clamp(currentIndex+1,1,nbRounds));

        //Get characteristics to export
        int id1 = image1.ID;
        int id2 = image2.ID;
        int winId = 0;
        if (winImage == 1)
        {
            winId = id1;
            image1.win();
        }
        else
        {
            winId = id2;
            image2.win();
        }

        //Set PlayerID (only for the first match)
        PlayerStats.setPersonID(PlayerStats.age + id1.ToString() + id2.ToString());

        //Export
        StartCoroutine(PostOnGF(id1.ToString(), id2.ToString(), winId.ToString()));

    }

    IEnumerator PostOnGF(string id1, string id2, string winId)
    {
        if (export)
        {

            //Send results to form
            WWWForm form = new WWWForm();
            form.AddField(FormURLs.ageURL, age);
            form.AddField(FormURLs.genderURL, gender);
            form.AddField(FormURLs.residenceURL, residence);
            form.AddField(FormURLs.originURL, origin);
            form.AddField(FormURLs.percentageURL, percentage);
            form.AddField(FormURLs.id1URL, id1);
            form.AddField(FormURLs.id2URL, id2);
            form.AddField(FormURLs.winIdURL, winId);
            form.AddField(FormURLs.personIDURL, PlayerStats.personID);

            UnityWebRequest www = UnityWebRequest.Post(FormURLs.googleFormURL, form);

            yield return www.SendWebRequest();
        }

        //Load new images for next round
        UpdateNewImages();
    }

    public void restartGame()
    {
        endCanvas.SetActive(false);
        SceneManager.LoadScene("MainGame");
    }
}
