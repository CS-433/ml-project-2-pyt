﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ResidenceIF : MonoBehaviour
{
    public GameObject cantonsIF;
    public GameObject continentIF;
    public TextMeshProUGUI textMeshPro;

    [HideInInspector] public string currentChoice = "Lausanne";

    public void changeValue()
    {
        string currentText = textMeshPro.text;
        if (currentText == "Inside Switzerland")
        {
            continentIF.SetActive(false);
            cantonsIF.SetActive(true);

            currentChoice = "Canton";
        }
        else if (currentText == "Outside Switzerland")
        {
            cantonsIF.SetActive(false);
            continentIF.SetActive(true);

            currentChoice = "Continent";
        }
        else
        {
            cantonsIF.SetActive(false);
            continentIF.SetActive(false);

            currentChoice = "Lausanne";
        }
    }
}
