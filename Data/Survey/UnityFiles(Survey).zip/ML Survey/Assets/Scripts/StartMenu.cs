﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class StartMenu : MonoBehaviour
{
    [Header("Canvas and Panels")]
    public GameObject introCanvas;
    public GameObject dataCanvas;
    public GameObject infoPanel;

    [Header("Age")]
    public GameObject ageIFText;
    public GameObject ageWarning;

    [Header("Gender")]
    public GameObject genderIFText;

    [Header("Origin")]
    public OriginIF originIF;
    public GameObject originIFText;
    public GameObject canton_orIFText;
    public GameObject continent_orIFText;
    public GameObject originWarning;

    [Header("Residence")]
    public ResidenceIF residenceIF;
    public GameObject residenceIFText;
    public GameObject canton_resIFText;
    public GameObject continent_resIFText;
    public GameObject residenceWarning;

    [Header("Percentage")]
    public Slider percentageIF;
    public TextMeshProUGUI currentPercentage;

    //To store player data
    private string age;
    private string gender;
    private string origin;
    private string residence;
    private string percentage;

    public void getPlayerData()
    {
        FindObjectOfType<AudioManager>().Play("ImageClick");

        //Get data from Input Fields
        age = ageIFText.GetComponent<Text>().text;
        gender = genderIFText.GetComponent<TextMeshProUGUI>().text;
        origin = getOrigin();
        residence = getResidence();
        percentage = percentageIF.value.ToString();

        //CheckData before moving on
        if (checkData()) 
        {
            //Set PlayerStats
            PlayerStats.setPlayerStats(age, gender, origin, residence, percentage);

            //Load info pane
            infoPanel.SetActive(true);
        } 
    }

    public void ContinueBtn()
    {
        introCanvas.SetActive(false);
        dataCanvas.SetActive(true);
    }
    public void StartGame()
    {
        SceneManager.LoadScene("MainGame");
    }

    public void UpdateCurrentPercentage()
    {
        currentPercentage.text = ((int)(100*percentageIF.value)).ToString();
    }

    private bool checkData() // Check if data is correctly formatted
    {
        bool convert;
        uint tmp;
        convert = uint.TryParse(age, out tmp);

        bool ageOk = convert && tmp >= 1 && tmp <= 120;

        if (!ageOk)
        {
            ageWarning.SetActive(true);
        } else
        {
            ageWarning.SetActive(false);
        }

        bool originOk = origin != "...";

        if (!originOk)
        {
            originWarning.SetActive(true);
        } else
        {
            originWarning.SetActive(false);
        }

        bool residenceOk = residence != "...";

        if (!residenceOk)
        {
            residenceWarning.SetActive(true);
        } else
        {
            residenceWarning.SetActive(false);
        }

        return ageOk && originOk && residenceOk;
    }

    private string getOrigin()
    {
        string ret;

        string currentChoice = originIF.currentChoice;

        if(currentChoice == "Lausanne")
        {
            ret = "Lausanne";
        } else if(currentChoice == "Canton")
        {
            ret = canton_orIFText.GetComponent<TextMeshProUGUI>().text;
        } else //Continent
        {
            ret = continent_orIFText.GetComponent<TextMeshProUGUI>().text;
        }

        return ret;
    }

    private string getResidence()
    {
        string ret;

        string currentChoice = residenceIF.currentChoice;

        if (currentChoice == "Lausanne")
        {
            ret = "Lausanne";
        }
        else if (currentChoice == "Canton")
        {
            ret = canton_resIFText.GetComponent<TextMeshProUGUI>().text;
        }
        else //Continent
        {
            ret = continent_resIFText.GetComponent<TextMeshProUGUI>().text;
        }

        return ret;
    }
}
