﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class FormURLs 
{
    //URLS for GF
    public static string googleFormURL = "https://docs.google.com/forms/u/0/d/e/1FAIpQLSeG8lvAVFbjkzuv_yhH9YMvfz2CyxsqF0a9_hEvmvreRgah9A/formResponse";
    public static string ageURL = "entry.291187092";
    public static string genderURL = "entry.865595754";
    public static string originURL = "entry.581505740";
    public static string residenceURL = "entry.2045921993";
    public static string percentageURL = "entry.1784819807";
    public static string id1URL = "entry.1063228029";
    public static string id2URL = "entry.1227591942";
    public static string winIdURL = "entry.895405740";
    public static string personIDURL = "entry.147511667";
}
