﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MyImage : MonoBehaviour
{
    public Image UI_Image;
    public int ID;

    //Effects
    public Transform imgLocation;
    public GameObject winParticleSystem;

    public void win()
    {
        Instantiate(winParticleSystem, imgLocation.position, Quaternion.Euler(-90, 0, 0));
    }

    public void UpdateImage(int newId, Sprite newSprite)
    {
        UI_Image.sprite = newSprite;
        ID = newId;
    }
}
