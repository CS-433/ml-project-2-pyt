﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PlayerStats //Stores player static data to be exported for each response
{
    public static string age = "22";
    public static string gender = "M";
    public static string origin = "Europe";
    public static string residence = "Lausanne";
    public static string percentage = "0.7";
    public static string personID = "0";
    public static bool firstMatch = true;

    public static int level = 0;

    public static int currentXp = 0;
    public static int maxXp = 50;

    public static void setPlayerStats(string a, string g, string o, string r, string p)
    {
        age = a;
        gender = g;
        origin = o;
        residence = r;
        percentage = p;
    }

    public static void setPersonID(string i)
    {
        if(firstMatch)
        {
            firstMatch = false;
            personID = i;
        }
    }
}
