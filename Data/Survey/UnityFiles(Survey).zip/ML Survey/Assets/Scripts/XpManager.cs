﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class XpManager : MonoBehaviour
{
    [Header("Round")]
    public TextMeshProUGUI currentRound;
    public TextMeshProUGUI maxRound;

    [Header("Xp")]
    public Slider xpBar;
    public TextMeshProUGUI textValue;
    public TextMeshProUGUI textMax;
    public TextMeshProUGUI levelValueEndCanvas;
    public TextMeshProUGUI quoteEndCanvas;
    public TextMeshProUGUI canyouEndCanvas;
    public GameObject canyouFREndCanvas;

    public int maxLevel = 7;
    public int minXp = 2;
    public int maxXp = 7;
    public float thresholdMultiplier = 1.4f;

    [Header("ImagePuzzle")]
    public Transform[] locations;
    public GameObject spriteMaskPrefab;

    [Header("Effect")]
    public Transform levelLocation;
    public GameObject levelUpEffect;

    //Animators
    private Animator xpBarAnim;
    private Animator maxAnim;

    //Quote
    private string[] quotes;
    private string finalThanksQuote;

    //Other
    private AudioManager audioManager;

    private void Awake()
    {
        audioManager = FindObjectOfType<AudioManager>();
        maxRound.text = FindObjectOfType<NewGM>().nbRounds.ToString();

        //Quotes
        finalThanksQuote = "You actually got to level " + maxLevel.ToString() + "! Thank you so much! You can still play to contribute to the project."; ;
        quotes = new string[maxLevel + 1];
        quotes[0] = "\"Sometimes, when I close my eyes... I can't see.\"";
        quotes[1] = "\"Sometimes, when I close my eyes... I can't see.\"";
        quotes[2] = "\"Life is a soup, and I'm a fork.\"";
        quotes[3] = "\"When nothing goes right, go left.\"";
        quotes[4] = "\"I don't trust children, they're here to replace us.\"";
        quotes[5] = "\"Thank god I'm an atheist!\"";
        quotes[6] = "\"A day without sunshine is like... you know, night.\"";
        quotes[7] = "\"I did not fall, I attacked the floor. And I won!\"";


        //Recover xpdata
        xpBarAnim = xpBar.GetComponent<Animator>();
        maxAnim = textMax.GetComponent<Animator>();
        xpBar.maxValue = PlayerStats.maxXp;
        xpBar.value = PlayerStats.currentXp;

        textValue.text = PlayerStats.level.ToString();
        textMax.text = maxLevel.ToString();

        //Recover unlocked pieces
        for (int i = 0; i < PlayerStats.level; i++)
        {
            Instantiate(spriteMaskPrefab, locations[i].position, Quaternion.identity);
        }

        //Recover endcanvas
        levelValueEndCanvas.text = PlayerStats.level.ToString();
        quoteEndCanvas.text = quotes[PlayerStats.level];

        if(PlayerStats.level == maxLevel)
        {
            canyouEndCanvas.text = finalThanksQuote;
        }

    }

    public void endRound(int newRoundIndex)
    {
        addXp();
        currentRound.text = newRoundIndex.ToString();
    }

    private void addXp()
    {
        xpBarAnim.SetTrigger("pop");

        int value = Random.Range(minXp, maxXp);
        xpBar.value += value;
        PlayerStats.currentXp += value;

        if (xpBar.value == xpBar.maxValue)
        {
            if(PlayerStats.level != maxLevel)
            {
                increaseLevel();
            }
        }
        //Update endCanvas
        levelValueEndCanvas.text = PlayerStats.level.ToString();
        quoteEndCanvas.text = quotes[PlayerStats.level];
        if (PlayerStats.level == maxLevel)
        {
            canyouEndCanvas.text = finalThanksQuote;
            canyouFREndCanvas.SetActive(false);
        }
    }

    private void increaseLevel()
    {
        //Satisfaction effects
        Instantiate(levelUpEffect, levelLocation.position, Quaternion.identity);
        audioManager.Play("LevelUp");
        maxAnim.SetTrigger("pop");

        //Update new max value
        int newMaxValue = (int)(thresholdMultiplier * xpBar.maxValue);
        xpBar.maxValue = newMaxValue;
        xpBar.value = 0;
        PlayerStats.maxXp = newMaxValue;

        //Reset player xp
        PlayerStats.currentXp = 0;

        //Increase player level
        PlayerStats.level += 1;
        textValue.text = PlayerStats.level.ToString();

        //Add puzzle piece
        Instantiate(spriteMaskPrefab, locations[PlayerStats.level - 1].position, Quaternion.identity);
    }
}
